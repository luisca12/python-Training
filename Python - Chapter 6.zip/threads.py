# import threading
# import requests

# urls = [
#     "https://www.example.com",
#     "https://www.python.org",
#     "https://www.kyndryl.com"
# ]

# def fetch_url(url):
#     response = requests.get(url)
#     print(f"{url}: {len(response.text)} bytes")

# threads = []

# for url in urls:
#     thread = threading.Thread(target=fetch_url, args=(url,))
#     threads.append(thread)
#     thread.start()

# for thread in threads:
#     thread.join()

# print("All downloads complete!")


###################################################################################

# Router example 

import threading
import time
import random

routers = ["Router_1", "Router_2", "Router_3", "Router_4"]

def run_config(router, command):
    print(f"[{router}] Sending command: {command}")

    execution_time = random.uniform(1, 3)
    time.sleep(execution_time)
    print(f"[{router}] Finished command '{command}' in {execution_time:.2f}s")


config_command = "interface Gig0/1; no shutdown"

threads = []

for router in routers:
    t = threading.Thread(target=run_config, args=(router, config_command))
    threads.append(t)
    t.start()

# Wait for all threads to finish
for t in threads:
    t.join()

print("All configuration commands executed")
