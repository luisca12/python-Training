# Write text to a file

# with open("example.txt", "w") as file:
#     file.write("Hello Kyndryl team This is a text file.\n")
#     file.write("We can store any text we want here.")



################################################################################################################################ 

# Read a text file
with open("example.txt", "r") as file:
    content = file.read()

print(content)


################################################################################################################################
# Reading a file line-by-line

# with open("example.txt", "r") as file:
#     for line in file:
#         print("Line:", line.strip())

################################################################################################################################

#Appending || "a" mode adds new content to the end of the file

# with open("example.txt", "a") as file:
#     file.write("\nThis line was added later.")


################################################################################################################################

# Saving a list to a .txt file

# names = ["Brantly", "Jon", "Chris"]

# with open("names.txt", "w") as file:
#     for name in names:
#         file.write(name + "\n")

################################################################################################################################

# Using .txt files for simple data storage

# Save a small note
# inventory = "Ports: 5\nCPUs: 3\nRam: 32GB"

# with open("savefile.txt", "w") as file:
#     file.write(inventory)

# with open("savefile.txt", "r") as file:
#     game_data = file.readlines()

# print(game_data)

################################################################################################################################

#Counting words in a text file

# with open("counting.txt", "w") as file:
#     file.write("This is a sample text file.\n")

# with open("counting.txt", "r") as file:
#     text = file.read()

# words = text.split()
# print("Word count:", len(words))


#Sample Switch Log File

################################################################################################################################


# with open("switch.log", "r") as file:
#     for line in file:
#         print(line.strip())


# with open("switch.log", "r") as file:
#     for line in file:
#         if "WARN" in line or "ERROR" in line:
#             print(line.strip())



################################################################################################################################
#Counting the number of log severity levels

# levels = {"INFO": 0, "WARN": 0, "ERROR": 0}

# with open("switch.log", "r") as file:
#     for line in file:
#         for level in levels:
#             if level in line:
#                 levels[level] += 1

# print(levels)

# down_ports = []

# with open("switch.log", "r") as file:
#     for line in file:
#         if "link down" in line:
#             port_number = line.split("Port")[1].split()[0]
#             down_ports.append(port_number)

# print("Ports that went down:", down_ports)


################################################################################################################################

# Writing filtered logs to another file

# with open("switch.log", "r") as infile, open("errors.log", "w") as outfile:
#     for line in infile:
#         if "ERROR" in line:
#             outfile.write(line)

################################################################################################################################

