#Example with txt 

# from netmiko import ConnectHandler

# device = {
#     "device_type": "cisco_ios",
#     "host": "192.168.21.136",
#     "username": "kris",
#     "password": "cisco",
# }

# connection = ConnectHandler(**device)
# output = connection.send_command("show ip interface brief")

# with open("interfaces.txt", "w") as file:
#     file.write(output)

# connection.disconnect()

##################################################################

#Example with csv

# import csv
# from netmiko import ConnectHandler

# device = {
#     "device_type": "cisco_ios",
#     "host": "192.168.21.136",
#     "username": "kris",
#     "password": "cisco",
# }

# connection = ConnectHandler(**device)
# output = connection.send_command("show interfaces description")

# rows = []
# for line in output.splitlines()[1:]:
#     parts = line.split()
#     if len(parts) >= 3:
#         Interface = parts[0]
#         Status = parts[1]
#         Protocol = parts[2]
#         Description = " ".join(parts[3:]) if len(parts) > 3 else ""
#         rows.append([Interface, Status, Protocol, Description])


# connection.disconnect()

# with open("port_status.csv", "w", newline="") as f:
#     writer = csv.writer(f)
#     writer.writerow(["Interface", "Status", "Protocol", "Description"])
#     writer.writerows(rows)



#####################################################################################################

# Example with word


# from docx import Document
# from netmiko import ConnectHandler

# def fill_template(template, output, replacements):
#     doc = Document(template)
#     for p in doc.paragraphs:
#         for key, value in replacements.items():
#             if key in p.text:
#                 p.text = p.text.replace(key, value)
#     doc.save(output)

# device = {
#     "device_type": "cisco_ios",
#     "host": "192.168.21.136",
#     "username": "kris",
#     "password": "cisco",
# }

# connection = ConnectHandler(**device)
# hostname = connection.send_command("show run | in hostname")
# version = connection.send_command("show version | inc Version")
# interfaces = connection.send_command("show ip int bri")
# uptime = connection.send_command("show version | include uptime")
# connection.disconnect()

# replacements = {
#     "{{DEVICE}}": hostname,
#      "{{VERSION}}": version,
#     "{{UPTIME}}": uptime,
#     "{{PORTS}}": interfaces
# }

# fill_template("template_net.docx", "final_switch_report.docx", replacements)
