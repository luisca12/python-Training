## Reading a CSV file using csv.reader
import csv

with open("ports.csv", "r") as file:
    csv_reader = csv.reader(file)
    for row in csv_reader:
        print(row)


##############################################################################

# Reading a CSV file as dictionaries (csv.DictReader)
# import csv

# with open("ports.csv", "r") as file:
#     csv_reader = csv.DictReader(file)
#     for row in csv_reader:
#         print(row["port"], row["status"])


##############################################################################

#Filtering down ports

import csv

down_ports = []

with open("ports.csv", "r") as file:
    reader = csv.DictReader(file)
    for row in reader:
        if row["status"] == "down":
            down_ports.append(row["port"])

print("Ports that are down:", down_ports)


##############################################################################

#  Writing CSV data to a file

# import csv

# data = [
#     ["port", "status", "errors"],
#     [1, "up", 0],
#     [2, "down", 34],
#     [3, "up", 2]
# ]

# with open("errors.csv", "w", newline="") as file:
#     writer = csv.writer(file)
#     writer.writerows(data)


##############################################################################

#  Appending rows to a CSV file

# import csv

# new_row = ["Ten1/6" , "up", "100Mbps", 99]

# with open("ports.csv", "a", newline="") as file:
#     writer = csv.writer(file)
#     writer.writerow(new_row)


# Writing only specific rows

import csv

with open("ports.csv", "r") as infile, open("vlan10.csv", "w", newline="") as outfile:
    reader = csv.DictReader(infile)
    fieldnames = reader.fieldnames
    writer = csv.DictWriter(outfile, fieldnames=fieldnames)

    writer.writeheader()

    for row in reader:
        if row["vlan"] == "10":
            writer.writerow(row)
