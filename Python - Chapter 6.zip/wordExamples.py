from docx import Document

doc = Document()
doc.add_heading("Switch Report", level=1)
doc.add_paragraph("This report contains switch port status information.")

doc.save("switch_report.docx")


########################################################################################################

#Writing switch log data into a Word document

# from docx import Document

# ports = ["Port 1 up", "Port 2 down", "Port 3 up"]

# doc = Document()
# doc.add_heading("Switch Port Status", level=1)

# for entry in ports:
#     doc.add_paragraph(entry)

# doc.save("port_status.docx")

########################################################################################################


#Reading text from a Word document

# from docx import Document

# doc = Document("port_status.docx")

# for para in doc.paragraphs:
#     print(para.text)


########################################################################################################

#Python code to read the Word document and replace text placeholders with actual data

from docx import Document

def replace_text_in_doc(template_path, output_path, replacements):
    doc = Document(template_path)

  
    for p in doc.paragraphs:
        for key, value in replacements.items():
            if key in p.text:
                p.text = p.text.replace(key, value)

  
    for table in doc.tables:
        for row in table.rows:
            for cell in row.cells:
                for key, value in replacements.items():
                    if key in cell.text:
                        cell.text = cell.text.replace(key, value)

    doc.save(output_path)



replacements = {
    "{{DEVICE}}": "Switch-23B",
    "{{IP}}": "192.168.10.45",
    "{{STATUS}}": "All ports operational"
}

replace_text_in_doc("template.docx", "switch_report_final.docx", replacements)
